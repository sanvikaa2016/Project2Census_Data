package task;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class MyKey implements WritableComparable {
	DoubleWritable inc;
    
	public DoubleWritable getInc() {
		return inc;
	}

	public void setInc(DoubleWritable inc) {
		this.inc = inc;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		inc.readFields(arg0);
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		inc.write(arg0);
		
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
     
}
