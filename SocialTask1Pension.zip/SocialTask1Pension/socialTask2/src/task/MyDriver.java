package task;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException, URISyntaxException {
		Configuration cfg=new Configuration();
	try{
		System.out.println("Pension in Year : Enter Year");
		Scanner sc=new Scanner(System.in);
		int year=sc.nextInt();
		cfg.setInt("year", year);
		if((year>=2017)&&(year<2050)){
		Job job=new Job(cfg,"Social 1 Total Pension in Year");
		job.setNumReduceTasks(1);
		job.setMapperClass(MyMapper.class);
		job.setJarByClass(MyDriver.class);
		job.setReducerClass(MyReducer.class);
		job.setInputFormatClass(MyInputFormat.class);
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		DistributedCache.addCacheFile(new URI("/pension.txt"), job.getConfiguration());
   	 
        sc.close();
		System.exit(job.waitForCompletion(true)?0:1);
		}
		else
		{
			System.out.println("Pls enter year between 2016 and 2050");
		}
	}
	catch(Exception e)
	{
		System.out.println("Pls enter valid value");
		
	}
	}

}
